#!/usr/bin/env bash

# $1 is track_type
gnome-terminal -- bash -c "./dev_graic.sh /home/zutshi/work/graic22dc $1"
