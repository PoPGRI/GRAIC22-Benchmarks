docker exec -it graic_con /bin/bash -c "~/workspace/carla-simulator/CarlaUE4.sh -opengl"
